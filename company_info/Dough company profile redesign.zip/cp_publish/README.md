# Dough Company Profile: handover

Static site, 47 landscape pages (1920 × 1358 design size, scaled to the window). Target: **https://xdough.com/cp/**

## Run locally
`npx serve .` in this folder, open the URL. Use ← / → to change pages. Must be served over HTTP (not `file://`).

## Publish
1. Upload the folder contents to the site's `cp/` route, keeping the structure (all paths are relative).
2. Redirect `/cp` to `/cp/`.
3. Serve over HTTPS with gzip/brotli and long cache headers on `assets/`.

## Files
- `index.html`: the whole profile (every page is a `<section>`, copy and layout inline).
- `support.js`, `deck-stage.js`, `image-slot.js`: required runtime. Do not delete.
- `assets/`: all images and the one video.

## Known to-dos before launch
- **File size:** `assets/` is ~100 MB. Convert images to WebP, cap long edge at ~2400 px, update the paths in `index.html`.
- **Head tags:** add `<title>Dough — Company Profile</title>`, meta description, Open Graph image (page 1), and `noindex` if it should stay unlisted.
- **Contact page links:** hello@xdough.com, https://www.instagram.com/dough.eg/, https://www.linkedin.com/company/xdough. "Get directions" needs the studio's Google Maps pin.
- **Rights:** confirm permission to publish Unilever (Lux, Knorr) and Heinz work.
- **Cover photo** (`assets/v3/n2-0.png`) is only 800 px wide; replace with a higher-res original if available.
- **Heinz standee logo** (page 47 area) is upscaled from a small photo; replace with the vector logo when available.
- Fonts: Montserrat via Google Fonts (needs internet).

## Design reference
Colours: navy `#122940`, steel blue `#457D9E`, pale blue `#C4D9EB`, cream `#FFFCF7`, warm grey `#E9E8E6`. Type: Montserrat only, weights 300–700, lowercase display headlines with the key word in 700. Outer margins 150 px, minimum text 24 px at design size.

The page uses a video (`assets/ai/lux-grapefruit.mp4`) that shows a still until played.
